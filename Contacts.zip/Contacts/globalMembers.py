dicObJPerson = {}
contactsListForJson = {}
firstName = ""
lastName = ""
phoneNumber = ""
